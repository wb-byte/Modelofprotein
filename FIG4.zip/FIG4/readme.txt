python stepping1.py > xx.txt
python stepping2.py > xxx.txt
python stepping3.py > coor.txt