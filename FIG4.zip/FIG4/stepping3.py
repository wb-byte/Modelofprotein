import numpy as np
import math
import random

Ini = np.loadtxt('xxx.txt')
Inib = np.loadtxt('ou.txt')


ter1 = int(len(Ini)/4.0)
ter2 = int(len(Inib)/4.0)
ter = 0
if ter1 > ter2:
   ter = ter2
else:
   ter = ter1

for tim in range(0,ter-1):
    si = 0
    num = 0
    for I in range(0,6):
        if Ini[tim*6+I,1] == 0:
           if Inib[tim*6+I,0]/0.34 - int(Inib[tim*6+I,0]/0.34) > 0.5:
               si = 12 + int(Inib[tim*6+I,0]/0.34) + 1
           elif Inib[tim*6+I,0]/0.34 - int(Inib[tim*6+I,0]/0.34) < 0.5:
               si = 12 + int(Inib[tim*6+I,0]/0.34)
        elif Ini[tim*6+I,1] != 0:
           num += 1
           si = Ini[tim*6+I,2]
        

        
        print tim,si,Inib[tim*6+1,1]/0.34,num/6.0,Ini[tim*6+I,3]
