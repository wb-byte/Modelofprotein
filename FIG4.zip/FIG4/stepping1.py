import numpy as np
import math
import random

Ini = np.loadtxt('x.txt')
    
counter = 0
num = 0
ter = len(Ini)

for tim in range(0,ter):

    if Ini[tim,0] == counter:
       num += 1
       print counter,Ini[tim,1],Ini[tim,2],Ini[tim,3]
       u = Ini[tim,3]
    
    if Ini[tim,0] == counter+1:
       if num < 6:
          for i in range(0,6-num):
             print counter,0,0,0
          num = 1
          counter += 1
          print counter,Ini[tim,1],Ini[tim,2],Ini[tim,3]
       elif num == 6:
          num = 0
          counter += 1
          
    elif Ini[tim,0] > counter+1:
       J = int(Ini[tim,0] - counter-1)
       if num < 6:
          for i in range(0,6-num):
             print counter,0,0,0
          counter += 1
          num = 0
       elif num == 6:
          num = 0
          counter += 1
          
       for K in range(0,J):
          for j in range(0,6):
              print counter,0,0,0
          counter += 1
    
 
    
