import numpy as np
import math
import random

Ini = np.loadtxt('xx.txt')


counter = 0
num = 0

ter = int(len(Ini)/4.0)

for tim in range(0,ter-1):
    si = 0
    num = 1
    for I in range(0,6):
        if Ini[tim*6+I,1] == 1 and num < 7:
           print Ini[tim*6+I,0],Ini[tim*6+I,1],Ini[tim*6+I,2],Ini[tim*6+I,3]
           si = 1
           num += 1
    if si == 0 and num < 7:
       num += 1
    
       print tim,0,0,0
           
    si = 0
    for I in range(0,6):
        if Ini[tim*6+I,1] == 2 and num < 7:
           print Ini[tim*6+I,0],Ini[tim*6+I,1],Ini[tim*6+I,2],Ini[tim*6+I,3]
           si = 1
           num += 1
           
           
    if si == 0 and num < 7:
       num += 1
       print tim,0,0,0

    si = 0
    for I in range(0,6):
        if Ini[tim*6+I,1] == 3 and num < 7:
           print Ini[tim*6+I,0],Ini[tim*6+I,1],Ini[tim*6+I,2],Ini[tim*6+I,3]
           si = 1
           num += 1
           
           
    if si == 0 and num < 7:
       num += 1
    
    
       print tim,0,0,0
       
    si = 0
    for I in range(0,6):
        if Ini[tim*6+I,1] == 4 and num < 7:
           print Ini[tim*6+I,0],Ini[tim*6+I,1],Ini[tim*6+I,2],Ini[tim*6+I,3]
           si = 1
           num += 1
           
           
    if si == 0 and num < 7:
    
           num += 1
           print tim,0,0,0

    si = 0
    for I in range(0,6):
        if Ini[tim*6+I,1] == 5 and num < 7:
           print Ini[tim*6+I,0],Ini[tim*6+I,1],Ini[tim*6+I,2],Ini[tim*6+I,3]
           si = 1
           num += 1
           
           
    if si == 0 and num < 7:
    
       num += 1
       print tim,0,0,0
       
    si = 0
    for I in range(0,6):
        if Ini[tim*6+I,1] == 6 and num < 7:
           print Ini[tim*6+I,0],Ini[tim*6+I,1],Ini[tim*6+I,2],Ini[tim*6+I,3]
           si = 1
           num += 1
           
           
    if si == 0 and num < 7:
       print tim,0,0,0
