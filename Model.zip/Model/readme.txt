Compiling the code:  $ python setup_fast_pdist1.py build_ext --inplace
Running the code: $ python test.py 
