import time
import model

start = time.clock()

if __name__ == "__main__":
    model.main()

  
end = time.clock()

print('Running time: %s Seconds'%(end-start))




